n = int(input())

for i in range(n):
	a = int(input())
	if a % 2 == 0:
		print("YES")
	else:
		print("NO")
